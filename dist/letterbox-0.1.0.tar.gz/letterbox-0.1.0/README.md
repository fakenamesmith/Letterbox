Command line tool for adding crop bars to multiple images to bring them to a given aspect ratio.
